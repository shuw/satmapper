/*
 * FileHole.java
 *
 * Created on May 7, 2001, 1:51 PM
 */

package ca.gc.space.quicksat.ground.pacsat;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class FileHole extends Object {

public int offset;
public int length;

    /** Creates new FileHole */
    public FileHole() {
    }
    public String toString() { return(""); }

}
