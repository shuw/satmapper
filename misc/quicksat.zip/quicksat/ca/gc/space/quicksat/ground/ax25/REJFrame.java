/*
 * REJFrame.java
 *
 * Created on October 11, 2001, 2:42 PM
 */

package ca.gc.space.quicksat.ground.ax25;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class REJFrame extends SupervisoryFrame {

    /** Creates new REJFrame */
    public REJFrame() {
    }
    public String toString() { return(super.toString()); }

}
