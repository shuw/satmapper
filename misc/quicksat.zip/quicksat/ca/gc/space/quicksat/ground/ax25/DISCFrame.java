/*
 * DISCFrame.java
 *
 * Created on October 11, 2001, 2:34 PM
 */

package ca.gc.space.quicksat.ground.ax25;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class DISCFrame extends UnnumberedFrame {

    
    /** Creates new DISCFrame */
    public DISCFrame() {
    }
    public String toString() { return(super.toString()); }

}
