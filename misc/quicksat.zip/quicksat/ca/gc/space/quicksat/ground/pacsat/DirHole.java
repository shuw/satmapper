/*
 * DirHole.java
 *
 * Created on May 7, 2001, 2:30 PM
 */

package ca.gc.space.quicksat.ground.pacsat;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class DirHole extends Object {
private int start;
private int stop;

    /** Creates new DirHole */
    public DirHole() {
    }
    public String toString() { return(""); }

}
