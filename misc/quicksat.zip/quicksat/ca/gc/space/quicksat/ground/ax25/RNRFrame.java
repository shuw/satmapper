/*
 * RNRFrame.java
 *
 * Created on October 11, 2001, 2:38 PM
 */

package ca.gc.space.quicksat.ground.ax25;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class RNRFrame extends SupervisoryFrame {

    /** Creates new RNRFrame */
    public RNRFrame() {
    }
    public String toString() { return(super.toString()); }
    
}
