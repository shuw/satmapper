/*
 * UnnumberedFrame.java
 *
 * Created on October 11, 2001, 2:30 PM
 */

package ca.gc.space.quicksat.ground.ax25;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class UnnumberedFrame extends Frame {
    /** Creates new UnnumberedFrame */
    public UnnumberedFrame() {
        initialized = true;
    }
    public String toString() { return(super.toString()); }
    

}
