/*
 * FRMRFrame.java
 *
 * Created on October 11, 2001, 2:36 PM
 */

package ca.gc.space.quicksat.ground.ax25;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class FRMRFrame extends UnnumberedFrame {

    /** Creates new FRMRFrame */
    public FRMRFrame() {
    }
    public String toString() { return(super.toString()); }

}
