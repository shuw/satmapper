/*
 * RequestFrame.java
 *
 * Created on May 7, 2001, 1:52 PM
 */

package ca.gc.space.quicksat.ground.pacsat;

import java.util.*;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class RequestFrame extends java.lang.Object {
private RequestHeader header;
private Vector fileHoleList;
private int crc;
    
    /** Creates new RequestFrame */
    public RequestFrame() {
    }

}
