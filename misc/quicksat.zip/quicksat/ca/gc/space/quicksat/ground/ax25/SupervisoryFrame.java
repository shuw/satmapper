/*
 * SupervisoryFrame.java
 *
 * Created on October 11, 2001, 2:31 PM
 */

package ca.gc.space.quicksat.ground.ax25;

/**
 *
 * @author  jfcusson
 * @version 
 */
public class SupervisoryFrame {

    /** Creates new SupervisoryFrame */
    public SupervisoryFrame() {
    }
    public String toString() { return(super.toString()); }

}
