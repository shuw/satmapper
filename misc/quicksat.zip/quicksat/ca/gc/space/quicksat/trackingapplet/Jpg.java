package ca.gc.space.quicksat.trackingapplet;

/**
 * Insert the type's description here.
 * Creation date: (3/12/2002 1:21:38 PM)
 * @author: 
 */
public class Jpg {
/**
 * Jpg constructor comment.
 */
public Jpg() {
	super();
}
}
