package com.csa.qks.vwr;

/**
 * Insert the type's description here.
 * Creation date: (3/25/2002 10:06:44 AM)
 * @author: 
 */
public class LocalSatBuilder {
/**
 * LocalSatBuilder constructor comment.
 */
public LocalSatBuilder() {
	super();
}
}
