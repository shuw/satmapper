/*
 * SatAnimate.java
 *
 * Created on February 19, 2002, 11:08 AM
 */

/**
 *
 * @author  TWu
 * @version 
 */
public class SatAnimate {

    /** Creates new SatAnimate */
    public SatAnimate() {
        
        
    }
    

    
    //increment angle to update according to orientation so angle dosen't change too fast
    
    
    int numImages = 8;
    Image satRotate[] = new Image
    
    int i;
    if ( currentAngle < angle)
        currentAngle += 25;
        currentAngle = (int)(angle / ;
        satRotate = new Image( getDocumentBase() + "/images/satRotate/" , "satRotate" + count + ".gif");
        
    }
        
    

}
