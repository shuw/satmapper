import java.util.*;
import java.awt.*;

public class SpriteEngine extends java.applet.Applet {
    //list of all sprites we are keeping track of
    private Vector spritelist;
    
    //accessible to child for game purposes
    protected int screenWidth, screenHeight;
    
    //for double buffering
    private Image bugger;
    private Graphics offscreen;
    
    // for color or image background support
    private Color bgcolor;
    private Image bgImage;
    
    //for frame counting
    private long startTime, stopTime;
    private int frameCounter;
}