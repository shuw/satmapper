EasyCharts example using ASP to read from an MS Access database
---------------------------------------------------------------

This example is to demonstrate how to retrieve data from a
database and create an EasyCharts applet to display the
data graphically on a web page.


INSTRUCTIONS:

Place the employees.mdb and departments.asp files in a folder on an 
MS IIS web server, or on your own computer if you just want to look 
at the code.

Type in the url for the departments.asp file.


Copyright note: All files with this distribution is copyrighted 
by ObjectPlanet Inc. Redistribution can only be done with
agreement from ObjectPlanet Inc.

ObjectPlanet Inc. takes no responsibility for any economical
or any other types of loss by using this software.